<?php
// main_true_false.php
session_start();
require 'db.php';

// Pastikan siswa sudah login
if (!isset($_SESSION['id_siswa'])) {
    header("Location: login.php");
    exit;
}

$id_siswa = $_SESSION['id_siswa'];
$id_game = $_GET['game'] ?? 0;

// Ambil pertanyaan untuk game
$stmt = $db->prepare("SELECT * FROM true_false_question WHERE id_game=? ORDER BY RAND()");
$stmt->execute([$id_game]);
$pertanyaan = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Jika hasil dikirim dari AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $skor = $_POST['skor'];
    $stmt = $db->prepare("INSERT INTO true_false_result (id_siswa, id_game, skor) VALUES (?, ?, ?)");
    $stmt->execute([$id_siswa, $id_game, $skor]);
    echo "OK";
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Main Game True/False</title>
<style>
body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; }
button { padding: 10px 20px; margin: 10px; font-size: 16px; cursor: pointer; }
#box { font-size: 20px; margin: 30px; }
</style>
</head>
<body>

<h2>🎯 Game True or False</h2>
<div id="box"></div>
<button onclick="jawab(true)">Benar</button>
<button onclick="jawab(false)">Salah</button>
<div id="hasil"></div>

<script>
const pertanyaan = <?= json_encode($pertanyaan) ?>;
let index = 0;
let skor = 0;

function tampilkan() {
  if (index < pertanyaan.length) {
    document.getElementById('box').textContent = pertanyaan[index].pertanyaan;
  } else {
    document.getElementById('box').innerHTML = `🎉 Selesai! Skor Anda: ${skor}/${pertanyaan.length}`;
    document.getElementById('hasil').textContent = '';
    kirimHasil();
  }
}

function jawab(ans) {
  const benar = pertanyaan[index].jawaban == 1;
  if (ans === benar) {
    skor++;
    document.getElementById('hasil').textContent = "✅ Jawaban benar!";
  } else {
    document.getElementById('hasil').textContent = "❌ Jawaban salah!";
  }
  index++;
  setTimeout(tampilkan, 700);
}

// Kirim hasil ke server (AJAX)
function kirimHasil() {
  fetch(window.location.href, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: "skor=" + skor
  })
  .then(res => res.text())
  .then(text => {
    if (text === "OK") {
      document.getElementById('hasil').textContent = "📊 Nilai Anda telah disimpan.";
    } else {
      document.getElementById('hasil').textContent = "⚠️ Gagal menyimpan skor.";
    }
  });
}

tampilkan();
</script>
</body>
</html>
