<?php
// guru_true_false.php
session_start();
require 'db.php'; // file koneksi PDO Anda

// Pastikan guru sudah login
if (!isset($_SESSION['id_guru'])) {
    header("Location: login.php");
    exit;
}

$id_guru = $_SESSION['id_guru'];

// Buat game jika belum ada
$stmt = $db->prepare("SELECT * FROM true_false_game WHERE id_guru = ? LIMIT 1");
$stmt->execute([$id_guru]);
$game = $stmt->fetch();

if (!$game) {
    $db->prepare("INSERT INTO true_false_game (id_guru, judul) VALUES (?, 'Game Pertama Saya')")
       ->execute([$id_guru]);
    $id_game = $db->lastInsertId();
} else {
    $id_game = $game['id_game'];
}

// Tambah pertanyaan baru
if (isset($_POST['tambah'])) {
    $stmt = $db->prepare("INSERT INTO true_false_question (id_game, pertanyaan, jawaban) VALUES (?, ?, ?)");
    $stmt->execute([$id_game, $_POST['pertanyaan'], $_POST['jawaban']]);
}

// Update pertanyaan
if (isset($_POST['ubah'])) {
    $stmt = $db->prepare("UPDATE true_false_question SET pertanyaan=?, jawaban=? WHERE id_question=?");
    $stmt->execute([$_POST['pertanyaan'], $_POST['jawaban'], $_POST['id_question']]);
}

// Hapus pertanyaan
if (isset($_GET['hapus'])) {
    $stmt = $db->prepare("DELETE FROM true_false_question WHERE id_question=?");
    $stmt->execute([$_GET['hapus']]);
}

// Ambil semua pertanyaan
$stmt = $db->prepare("SELECT * FROM true_false_question WHERE id_game = ?");
$stmt->execute([$id_game]);
$pertanyaan = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Kelola Game True/False</title>
<style>
body { font-family: Arial, sans-serif; margin: 30px; }
table { border-collapse: collapse; width: 100%; margin-top: 20px; }
td, th { border: 1px solid #ccc; padding: 8px; text-align: left; }
input[type=text] { width: 90%; padding: 5px; }
button { padding: 6px 10px; }
</style>
</head>
<body>

<h2>🧠 Kelola Game True / False</h2>

<h3>Tambah Pertanyaan Baru</h3>
<form method="POST">
  <label>Pertanyaan:</label><br>
  <input type="text" name="pertanyaan" required><br><br>
  <label>Jawaban:</label>
  <select name="jawaban">
    <option value="1">Benar</option>
    <option value="0">Salah</option>
  </select>
  <button name="tambah">Tambah</button>
</form>

<h3>Daftar Pertanyaan</h3>
<table>
<tr><th>ID</th><th>Pertanyaan</th><th>Jawaban</th><th>Aksi</th></tr>
<?php foreach($pertanyaan as $q): ?>
<tr>
  <form method="POST">
    <td><?= $q['id_question'] ?><input type="hidden" name="id_question" value="<?= $q['id_question'] ?>"></td>
    <td><input type="text" name="pertanyaan" value="<?= htmlspecialchars($q['pertanyaan']) ?>"></td>
    <td>
      <select name="jawaban">
        <option value="1" <?= $q['jawaban'] ? 'selected' : '' ?>>Benar</option>
        <option value="0" <?= !$q['jawaban'] ? 'selected' : '' ?>>Salah</option>
      </select>
    </td>
    <td>
      <button name="ubah">💾 Simpan</button>
      <a href="?hapus=<?= $q['id_question'] ?>" onclick="return confirm('Hapus pertanyaan ini?')">🗑️ Hapus</a>
    </td>
  </form>
</tr>
<?php endforeach; ?>
</table>

<p><strong>Link bermain:</strong> 
  <a href="main_true_false.php?game=<?= $id_game ?>">main_true_false.php?game=<?= $id_game ?></a>
</p>

</body>
</html>
