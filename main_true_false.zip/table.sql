-- Tabel game utama (dimiliki oleh guru)
CREATE TABLE `true_false_game` (
  `id_game` INT AUTO_INCREMENT PRIMARY KEY,
  `id_guru` INT NOT NULL,
  `judul` VARCHAR(100) NOT NULL,
  `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`id_guru`) REFERENCES `guru`(`id_guru`)
);

-- Tabel pertanyaan true/false
CREATE TABLE `true_false_question` (
  `id_question` INT AUTO_INCREMENT PRIMARY KEY,
  `id_game` INT NOT NULL,
  `pertanyaan` TEXT NOT NULL,
  `jawaban` TINYINT(1) NOT NULL, -- 1 = Benar, 0 = Salah
  FOREIGN KEY (`id_game`) REFERENCES `true_false_game`(`id_game`)
);

CREATE TABLE `true_false_result` (
  `id_result` INT AUTO_INCREMENT PRIMARY KEY,
  `id_siswa` INT NOT NULL,
  `id_game` INT NOT NULL,
  `skor` INT NOT NULL,
  `tanggal` DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`id_siswa`) REFERENCES `siswa`(`id_siswa`),
  FOREIGN KEY (`id_game`) REFERENCES `true_false_game`(`id_game`)
);
