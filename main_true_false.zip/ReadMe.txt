https://chatgpt.com/share/68f79e68-29d8-8008-ab08-dd5e7a5a6305

coba di db ikam yu